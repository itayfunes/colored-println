package main

import (
	"log"
	"middle-tcp-go/src/handler/job"
	"middle-tcp-go/src/server"
	"os"
	"os/signal"
	"syscall"
)

func main() {
	serveClient, serveServer := server.Init()

	go job.Init()
	go serveClient.Start()
	go serveServer.Start()

	stopOrKillServer()
}

func stopOrKillServer() {
	signals := make(chan os.Signal, 1)
	signal.Notify(signals, syscall.SIGTERM, syscall.SIGINT, os.Interrupt)
	sig := <-signals
	log.Println("\nReceive Signal from OS - Release resource")
	job.Release()
	log.Println(sig)
	os.Exit(0)
}
