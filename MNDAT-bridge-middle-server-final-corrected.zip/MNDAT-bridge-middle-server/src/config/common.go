package config

type Config struct {
	Name            string
	ServeClientConf *ServerConfig
	ServeServerConf *ServerConfig
	MasterIp        string
	MasterPort      string
	ClientPort      string
	ServerPort      string
}

type ServerConfig struct {
	Ip   string
	Port string
	Host string
}

var config *Config

func NewConfig(cfg *Config) {
	config = cfg
	config.ServeClientConf.Host = config.ServeClientConf.Ip + ":" + config.ServeClientConf.Port
	config.ServeServerConf.Host = config.ServeServerConf.Ip + ":" + config.ServeServerConf.Port
}

func GetServerHost() string {
	return config.ServeServerConf.Host
}

func GetClientHost() string {
	return config.ServeClientConf.Host
}

func GetMasterHostInit() string {
	return config.MasterIp + ":" + config.MasterPort
}
