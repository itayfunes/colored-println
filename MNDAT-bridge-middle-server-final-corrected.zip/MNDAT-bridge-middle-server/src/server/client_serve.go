package server

import (
	"log"
	"middle-tcp-go/src/handler/job"
	"middle-tcp-go/src/handler/message"
	"net"
)

type ClientServe struct {
	listenAddr  string
	ln          net.Listener
	quitSignal  chan struct{}
	messageChan chan Msg
}

func newClientServer(listenAddr string) ClientServe {
	return ClientServe{
		listenAddr:  listenAddr,
		quitSignal:  make(chan struct{}),
		messageChan: make(chan Msg, NumberOfMessageChan),
	}
}

func (s ClientServe) Start() {
	ln, err := net.Listen("tcp", s.listenAddr)
	if err != nil {
		panic(err)
	}
	log.Println("[Client Served] Start client tcp server at: ", s.listenAddr)

	defer ln.Close()
	s.ln = ln
	go s.acceptConnection()
	go s.handleMess()
	<-s.quitSignal
	close(s.messageChan)
}

func (s ClientServe) acceptConnection() {
	for {
		conn, err := s.ln.Accept()
		if err != nil {
			log.Println("[Client Served] Cannot accepted connection: ", err)
			continue
		}

		log.Println("[Client Served] Connect to server from ", conn.RemoteAddr())
		go s.handlerConnection(conn)
	}
}

func (s ClientServe) handlerConnection(conn net.Conn) {
	defer conn.Close()
	buff := make([]byte, 2048)
	for {
		n, err := conn.Read(buff)
		if err != nil {
			log.Println(err)
			return
		}

		s.messageChan <- Msg{
			from:    conn.RemoteAddr().String(),
			payload: buff[:n],
			conn:    conn,
		}
	}
}

func (s ClientServe) handleMesacbs() {
	log.Println("[Client Served] Init handle client mess queue")
	for msgReceive := range s.messageChan {
		msg := &message.Message{}
		err := msg.Decode([]byte(msgReceive.payload))
		if err != nil {
			log.Println("[Client Served] Cannot decode client mess err: ", err)
			continue
		}

		var jobType job.JobType
		var addrTo string
		switch msg.Type {
		case message.MessageTypeCommand:
			jobType = job.JobType_SendServer
		case message.MessageTypeCreateBridge:
			jobType = job.JobType_CreateBridgeFromClient
		default:
			jobType = job.JobType_NotSupported
		}
		jobInfo := job.NewJobWithConn(jobType, msg.Data, msg.ClientAddress, addrTo, msgReceive.conn)
		go job.SendToJobQueue(jobInfo)
	}
}

func (s ClientServe) handleMess() {
	log.Println("[Client Served] Init handle client mess queue")
	for msgReceive := range s.messageChan {
		msg := &message.Message{}
		err := msg.Decode([]byte(msgReceive.payload))
		if err != nil {
			log.Println("[Client Served] Cannot decode client mess err: ", err)
			jobInfo := job.NewJobWithConn(job.JobType_SendServer, msg.Data, "", "", msgReceive.conn)
			go job.SendToJobQueue(jobInfo)
		} else {
			var jobType job.JobType
			var addrTo string
			switch msg.Type {
			case message.MessageTypeCommand:
				jobType = job.JobType_SendServer
			case message.MessageTypeCreateBridge:
				jobType = job.JobType_CreateBridgeFromClient
			default:
				jobType = job.JobType_NotSupported
			}
			jobInfo := job.NewJobWithConn(jobType, msg.Data, msg.ClientAddress, addrTo, msgReceive.conn)
			go job.SendToJobQueue(jobInfo)
		}
	}
}
