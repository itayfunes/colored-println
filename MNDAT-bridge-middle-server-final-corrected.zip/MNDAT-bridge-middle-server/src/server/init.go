package server

import (
	"log"
	"middle-tcp-go/src/config"
	"middle-tcp-go/src/handler/job"
	"middle-tcp-go/src/handler/message"
	"middle-tcp-go/src/utils"
	"net"

	"github.com/joho/godotenv"
)

func Init(fileName ...string) (ServerTcp, ServerTcp) {
	initMasterHandleChan()
	err := godotenv.Load(fileName...)
	if err != nil {
		log.Fatal("Error loading .env file with err: ", err)
		panic("error loading .env file")
	}
	cfg := &config.Config{
		Name: utils.GetEnv("SERVER_NAME", "bridge-server"),
		ServeClientConf: &config.ServerConfig{
			Ip:   utils.GetEnv("SERVER_IP", "127.0.0.1"),
			Port: utils.GetEnv("ClientServedPort", "4433"),
		},
		ServeServerConf: &config.ServerConfig{
			Ip:   utils.GetEnv("SERVER_IP", "127.0.0.1"),
			Port: utils.GetEnv("ServerServedPort", "15319"),
		},
		MasterIp:   utils.GetEnv("MasterIP", "127.0.0.1"),
		MasterPort: utils.GetEnv("MasterPort", "1234"),
		ClientPort: utils.GetEnv("ClientPort", "6850"),
		ServerPort: utils.GetEnv("ServerPort", "1221"),
	}

	config.NewConfig(cfg)
	serveClient := newClientServer(config.GetClientHost())
	serveServer := newServerServer(config.GetServerHost())
	go startUp()
	go startWebServer()
	go sendInitToMaster()
	return serveClient, serveServer
}

func initMasterHandleChan() {
	messageMasterChan = make(chan Msg)
	go handleMess()
}

func sendInitToMaster() {
	masterHost := config.GetMasterHostInit()
	conn, err := net.Dial("tcp", masterHost)
	if err != nil {
		log.Println("Cannot connect to master, err: ", err)
		panic(err)
	}

	mess := message.NewMsg(message.MessageTypeInitBridge, []byte(KeyVerify), utils.GetLocalIP())
	messByte, err := mess.Encode()
	if err != nil {
		log.Println("Cannot encode mess init to master, err: ", err)
		panic(err)
	}

	_, err = conn.Write(messByte)
	if err != nil {
		log.Println("Cannot send message init to master, err", err)
		panic(err)
	}
	job.MasterConnection = conn
	go listenToMaster(job.MasterConnection)
	log.Println("Init bridge to master")
}
