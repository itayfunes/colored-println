package server

import "net"

const NumberOfMessageChan = 1_000_000
const KeyVerify = "V4lqNUFdqXleFWg"

var messageMasterChan chan Msg

type Msg struct {
	from    string
	payload []byte
	conn    net.Conn
}

type ServerTcp interface {
	Start()
	acceptConnection()
	handlerConnection(net.Conn)
	handleMess()
}
