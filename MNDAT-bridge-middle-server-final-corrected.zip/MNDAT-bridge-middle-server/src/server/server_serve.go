package server

import (
	"log"
	"middle-tcp-go/src/handler/job"
	"middle-tcp-go/src/handler/message"
	"net"
)

type ServerServe struct {
	listenAddr  string
	ln          net.Listener
	quitSignal  chan struct{}
	messageChan chan Msg
}

func newServerServer(listenAddr string) ServerServe {
	return ServerServe{
		listenAddr:  listenAddr,
		quitSignal:  make(chan struct{}),
		messageChan: make(chan Msg, NumberOfMessageChan),
	}
}

func (s ServerServe) Start() {
	ln, err := net.Listen("tcp", s.listenAddr)
	if err != nil {
		panic(err)
	}
	log.Println("[Server Served] Start server tcp server at: ", s.listenAddr)

	defer ln.Close()
	s.ln = ln
	go s.acceptConnection()
	go s.handleMess()
	<-s.quitSignal
	close(s.messageChan)
}

func (s ServerServe) acceptConnection() {
	for {
		conn, err := s.ln.Accept()
		if err != nil {
			log.Println("[Server Served] Cannot accepted connection: ", err)
			continue
		}

		log.Println("[Server Served] Connect to server from ", conn.RemoteAddr())
		go s.handlerConnection(conn)
	}
}

func (s ServerServe) handlerConnection(conn net.Conn) {
	defer conn.Close()
	buff := make([]byte, 2048)
	for {
		n, err := conn.Read(buff)
		if err != nil {
			log.Println(err)
			return
		}
		s.messageChan <- Msg{
			from:    conn.RemoteAddr().String(),
			payload: buff[:n],
		}
	}
}

func (s ServerServe) handleMess() {
	log.Println("[Server Served] Init handle server mess queue")
	for msg := range s.messageChan {
		log.Println("[Server Served] handle server message from: ", msg.from)
		mess := &message.Message{}
		err := mess.Decode(msg.payload)
		if err != nil {
			log.Println("[Server Served] cannot decode server message, err: ", err)
			continue
		}
		var typeJob job.JobType
		var addrTo string
		switch mess.Type {
		case message.MessageTypeCreateBridge:
			typeJob = job.JobType_CreateBridge
		case message.MessageTypeCommand:
			typeJob = job.JobType_SendCommand
			addrTo = mess.ClientAddress
		case message.MessageTypeDelete:
			typeJob = job.JobType_DeleteConnectionBridge
			addrTo = mess.ClientAddress
		default:
			typeJob = job.JobType_NotSupported
		}
		jobMess := job.NewJob(typeJob, mess.Data, mess.ClientAddress, addrTo)
		job.SendToJobQueue(jobMess)
	}
}
