package server

import (
	"log"
	"middle-tcp-go/src/handler/job"
	"middle-tcp-go/src/handler/message"
	"net"
)

func listenToMaster(conn net.Conn) {
	buffer := make([]byte, 2048)
	for {
		n, err := conn.Read(buffer)
		if err != nil {
			log.Println("Cannot read from master: ", err)
			return
		}

		messageMasterChan <- Msg{
			from:    conn.RemoteAddr().String(),
			payload: buffer[:n],
		}
	}
}

func handleMess() {
	log.Println("Init handle master mess queue")
	for msg := range messageMasterChan {
		mess := &message.Message{}
		err := mess.Decode(msg.payload)
		if err != nil {
			log.Println("cannot decode bridge message, err: ", err)
			continue
		}

		var typeJob job.JobType
		var addrTo string
		switch mess.Type {
		case message.MessageTypeCreateBridge:
			typeJob = job.JobType_CreateBridge
		case message.MessageTypeCheckInterval:
			continue
		default:
			typeJob = job.JobType_NotSupported
		}
		jobMess := job.NewJob(typeJob, mess.Data, mess.ClientAddress, addrTo)
		job.SendToJobQueue(jobMess)
	}
}
