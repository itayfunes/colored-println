package job

import (
	"log"
)

func Init() {
	log.Println("Init job queue")
	jobQueue = make(chan Job, 100_000)

	go QueueJob()
}

func Release() {
	log.Println("Close Job Queue")
	close(jobQueue)
	log.Println("Delete all connection to client and server")
	for _, p := range pairList {
		p.clientConn.Close()
		p.serverConn.Close()
	}
	MasterConnection.Close()
}

func SendToJobQueue(job Job) {
	jobQueue <- job
}

func QueueJob() {
	log.Println("Init handler job")
	for job := range jobQueue {
		switch job.jobType {
		case JobType_SendServer:
			handleSendToServer(job)
		case JobType_CreateBridge:
			handleCreateBridge(job)
		case JobType_SendCommand:
			handleSendCommand(job)
		case JobType_DeleteConnectionBridge:
			handleDeleteBridge(job)
		case JobType_CreateBridgeFromClient:
			handleCreateBridgeClient(job)
		default:
			log.Println("job type not supported, maybe invalid?")
		}
	}
}
