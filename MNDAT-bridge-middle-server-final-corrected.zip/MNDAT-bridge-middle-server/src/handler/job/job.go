package job

import "net"

type JobType int

const (
	JobType_NotSupported           JobType = 0
	JobType_ReceiveClient          JobType = 2
	JobType_ReceiveFileInfoClient  JobType = 3
	JobType_ReceiveFileDataClient  JobType = 4
	JobType_SendServer             JobType = 5
	JobType_SendFileServer         JobType = 6
	JobType_ReceiveServer          JobType = 7
	JobType_InitClient             JobType = 8
	JobType_InitServer             JobType = 9
	JobType_InitBridge             JobType = 10
	JobType_DeleteClient           JobType = 11
	JobType_DeleteBridge           JobType = 12
	JobType_DeleteServer           JobType = 13
	JobType_CreateBridge           JobType = 14
	JobType_SendCommand            JobType = 15
	JobType_SendFileToClient       JobType = 16
	JobType_DeleteConnectionBridge JobType = 17
	JobType_CreateBridgeFromClient JobType = 18
)

type Job struct {
	jobType  JobType
	data     []byte
	addrFrom string
	addrTo   string
	conn     net.Conn
}

func NewJob(t JobType, d []byte, addrF string, addT string) Job {
	return Job{
		jobType:  t,
		data:     d,
		addrFrom: addrF,
		addrTo:   addT,
	}
}

func NewJobWithConn(t JobType, d []byte, addrF string, addT string, conn net.Conn) Job {
	return Job{
		jobType:  t,
		data:     d,
		addrFrom: addrF,
		addrTo:   addT,
		conn:     conn,
	}
}

var jobQueue chan Job
