package job

import (
	"log"
	"middle-tcp-go/src/handler/message"
	"middle-tcp-go/src/utils"
	"net"
	"strings"
)

func handleSendCommand(j Job) {
	// Find client pair
	ps := pairList.GetListPairByServer(j.addrFrom)
	for _, p := range ps {
		// p := pairList.GetPair(j.addrFrom, j.addrTo)
		if p == nil {
			log.Printf("Cannot get pair connection [%s] - [%s], maybe haven't init?", j.addrFrom, j.addrTo)
			return
		}

		if p.clientConn == nil { // Incase client haven't have connection, init one
			clientConn, err := net.Dial("tcp", p.clientIp)
			if err != nil {
				log.Printf("Cannot send mess to client %s with err: %v", p.clientIp, err)
				return
			}
			_, err = clientConn.Write(j.data)
			if err != nil {
				log.Printf("Cannot send mess to client %s with err: %v", p.clientIp, err)
				return
			}
			p.clientConn = clientConn
		} else { // get connection and send
			// TODO: Check again here? what to send
			_, err := p.clientConn.Write(j.data)
			if err != nil {
				log.Printf("Cannot send mess to client %s with err: %v", p.clientIp, err)
				return
			}
		}
		log.Println("Send command to client complete")
	}
}

func i123handleSendCommand(j Job) {
	// Find client pair
	p := pairList.GetPair(j.addrFrom, j.addrTo)
	if p == nil {
		log.Printf("Cannot get pair connection [%s] - [%s], maybe haven't init?", j.addrFrom, j.addrTo)
		return
	}

	if p.clientConn == nil { // Incase client haven't have connection, init one
		clientConn, err := net.Dial("tcp", p.clientIp)
		if err != nil {
			log.Printf("Cannot send mess to client %s with err: %v", p.clientIp, err)
			return
		}
		_, err = clientConn.Write(j.data)
		if err != nil {
			log.Printf("Cannot send mess to client %s with err: %v", p.clientIp, err)
			return
		}
		p.clientConn = clientConn
	} else { // get connection and send
		// TODO: Check again here? what to send
		_, err := p.clientConn.Write(j.data)
		if err != nil {
			log.Printf("Cannot send mess to client %s with err: %v", p.clientIp, err)
			return
		}
	}
	log.Println("Send command to client complete")
}

func handleSendToServer(j Job) {
	if j.addrTo == "" || j.addrFrom == "" {
		if j.conn == nil {
			log.Println("No Info of client to find server")
			return
		}
		pList := pairList.GetAllServerByClientConn(j.conn)
		log.Printf("Find %d connection with client", len(pList))
		for _, p := range pList {
			go sendServer(p.serverIp, p.serverConn, j.data)
		}
	}
	p := pairList.GetPair(j.addrTo, j.addrFrom)
	if p == nil {
		log.Printf("Cannot get pair connection [%s] - [%s], maybe haven't init?", j.addrFrom, j.addrTo)
		return
	}

	sendServer(p.serverIp, p.serverConn, j.data)
	log.Println("Send command to server complete")
}

func sendServer(serverAddr string, serverConn net.Conn, data []byte) {
	if serverConn == nil { // Incase server haven't have connection, init one
		serverConn, err := net.Dial("tcp", serverAddr)
		if err != nil {
			log.Printf("Cannot send mess to server %s with err: %v", serverAddr, err)
			return
		}
		_, err = serverConn.Write(data)
		if err != nil {
			log.Printf("Cannot send mess to server %s with err: %v", serverAddr, err)
			return
		}
	} else { // get connection and send
		_, err := serverConn.Write(data)
		if err != nil {
			log.Printf("Cannot send mess to server %s with err: %v", serverAddr, err)
			return
		}
	}
}

func handleCreateBridge(j Job) {
	if string(j.data) == "" {
		log.Println("Missing data to create bridge")
		return
	}
	log.Println("create middle serve for pair: ", string(j.data))
	parts := strings.Split(string(j.data), "-")
	if len(parts) != 2 {
		log.Println("Invalid data create bridge")
		go sendRespCreateBridge("Invalid Body Create Bridge")
		return
	}
	serverAddr := parts[0]
	clientAddr := parts[1]
	go sendRespCreateBridge("success")
	pairList = pairList.AddToList(NewCSPairWithIp(serverAddr, clientAddr))
}

func sendRespCreateBridge(cause string) {
	mess := message.NewMsg(message.MessageTypeCreateBridgeResp, []byte(cause), utils.GetLocalIP())
	messByte, _ := mess.Encode()
	MasterConnection.Write(messByte)
}

func handleDeleteBridge(j Job) {
	if string(j.data) == "" {
		log.Println("Missing data to delete bridge")
		return
	}
	log.Println("delete middle serve for pair: ", string(j.data))
	parts := strings.Split(string(j.data), "-")
	if len(parts) != 2 {
		log.Println("Invalid data delete bridge")
		return
	}
	serverAddr := parts[0]
	clientAddr := parts[1]
	pairList = pairList.DeleteByCS(serverAddr, clientAddr)
}

func handleCreateBridgeClient(j Job) {
	if string(j.data) == "" {
		log.Println("Missing data to create bridge")
		return
	}
	clientAddr := string(j.data)
	csPairList := pairList.GetListPairByClient(clientAddr)
	for _, csPair := range csPairList {
		csPair.clientConn = j.conn
	}
}
