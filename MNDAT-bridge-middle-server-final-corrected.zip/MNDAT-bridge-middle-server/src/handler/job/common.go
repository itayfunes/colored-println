package job

import "net"

var (
	pairList         CSPairList
	MasterConnection net.Conn
)

const (
	ServerSvc = "server"
	ClientSvc = "client"
	BridgeSvc = "bridge"
)

const KeyVerify = "V4lqNUFdqXleFWg"
