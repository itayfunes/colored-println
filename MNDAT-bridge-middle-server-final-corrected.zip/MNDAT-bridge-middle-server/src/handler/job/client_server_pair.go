package job

import "net"

type CSPairList []*CSPair

func (p CSPairList) AddToList(csPair *CSPair) CSPairList {
	p = append(p, csPair)
	return p
}

func (p CSPairList) GetListPairByClient(clientIp string) []*CSPair {
	var pairs []*CSPair
	for _, v := range p {
		if v.clientIp == clientIp {
			pairs = append(pairs, v)
		}
	}
	return pairs
}

func (p CSPairList) GetListPairByServer(serverIp string) []*CSPair {
	var pairs []*CSPair
	for _, v := range p {
		if v.serverIp == serverIp {
			pairs = append(pairs, v)
		}
	}
	return pairs
}

func (p CSPairList) GetPair(serverIp, clientIp string) *CSPair {
	for _, v := range p {
		if v.serverIp == serverIp && v.clientIp == clientIp {
			return v
		}
	}
	return nil
}

func (p CSPairList) GetAllServerByClientConn(clientConn net.Conn) []*CSPair {
	var pairs []*CSPair
	for _, v := range p {
		if v.clientConn.RemoteAddr().String() == clientConn.RemoteAddr().String() {
			pairs = append(pairs, v)
		}
	}
	return pairs
}

func (p CSPairList) DeleteByCS(serverIp, clientIp string) CSPairList {
	var pairs []*CSPair
	for _, v := range p {
		if v.clientIp == clientIp && v.serverIp == serverIp {
			continue
		}
		pairs = append(pairs, v)
	}
	return pairs
}

type CSPair struct {
	serverIp   string
	serverConn net.Conn
	clientIp   string
	clientConn net.Conn
}

func NewCSPair() *CSPair {
	return &CSPair{}
}


func NewCSPairWithIp(serverIp, clientIp string) *CSPair {
    // Check if the client IP already contains a port
    if !strings.Contains(clientIp, ":") {
        // Append a default port (e.g., 12345) if no port is provided
        clientIp = clientIp + ":4433"
    }
    return &CSPair{
        serverIp: serverIp,
        clientIp: clientIp,
    }
}


func NewCsPairWithConnection(serverConn, clientConn net.Conn) *CSPair {
	return &CSPair{
		serverConn: serverConn,
		clientConn: clientConn,
	}
}

func NewCSpairWithClientIpAndConn(serverIp, clientIp string, clientConn net.Conn) *CSPair {
	return &CSPair{
		serverIp:   serverIp,
		clientConn: clientConn,
		clientIp:   clientIp,
	}
}
