#!/bin/bash

# Function to print text in cyan color
print_cyan() {
    echo -e "\e[36m$1\e[0m"
}

# Check if wget is installed, and if not, install it
check_and_install_wget() {
    if ! command -v wget &> /dev/null; then
        echo "[+] 'wget' command not found. Installing 'wget'..."
        sudo apt install -y wget
    fi
}

# Check if wget is installed, and if not, install it
check_and_install_go() {
    if ! command -v go &> /dev/null; then
        echo "[+] 'wget' command not found. Installing 'wget'..."
        sudo apt install -y golang-go
    fi
}

# Print ASCII art in cyan color
print_cyan "

	                                         #    #
                                            %%% ##   ##
                                         %%%%% ###%%###
                                        %%%%% ### %%% #
                                      %%%%%% ### %%% ###
                                       %%%% ## %% #######
                                      %%%%% # %% #O#####
                                    %%%%%% # % #########
                                   %%%%% ##### #########
                         ###        %% ####### #########
                %%% ############    ########### ########
             %%%% ############################### #######
           %%%%% ################################## ######
         %%%%%% #################################### #C###
        %%%%%% #####################################  ###
        %%%%% #######################################
       %%%%%% ########################################
    % %%%%%%% ########################################
     %%%%%%%%% #######################################
    %%%%%%%%%% ########################################
 %%% %%%%%%%%   ###### ################################
   %%%%%%%%      ###### #################### ##########
% %%%%%%%%        ####### ########### ###### ##########
 %%%%%%%%%         #######  ########### ###### ########
%%%%%%%%%%          ##### ###  ######### ####### ######
 %%%%%%%%%%          #### ##               ####### ####
 %%%%%%%%%%%           ## #                  ##### ###
  %%  %% % %%         # ##                      ## ###
    %   %    %        # ###                      # ###
                       # ###                     ## ###
                       # ###                     ## ###
                       # ####                   #### ##
                      ### ###                  ##### ###
                     ####  ###                 ####   ##
                    #####   ###                 ##    ##
                   #####    ####                      ###
                    ##        ###                     ###
                               ####                     ##
                                ####                    ###
                                                        ####
                                                         ##
														 
"

echo "[+] Updating package list..."
sudo apt update

echo "[+] Installing Golang..."
check_and_install_go

# Check if wget is installed and install if necessary
check_and_install_wget

echo "[+] Creating 'mndatv1' folder..."
mkdir -p mndatv1

echo "[+] Downloading file into 'mndatv1' folder..."
wget "<LINK-TO-EXECUTABLE" -P mndatv1/
chmod +x mndatv1/mndat_linux64

read -p "[+] Do you want to run MNDAT now? (y/n): " choice

if [ "$choice" == "y" ]; then
    echo "[+] Big love for contributing in MNDAT network! MNDAT will be running shortly"
    ./mndatv1/mndat_linux64
else
    echo "[-] Exiting..."
fi
